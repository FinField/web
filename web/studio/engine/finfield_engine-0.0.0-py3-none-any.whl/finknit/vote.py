"""Voting on what is factually correct — pulse for exact facts, vank for floats.

Two consensus regimes, matched to the nature of the number:

**Exact facts** (audited filing values): every honest node that reads the
same filing mints the byte-identical CID, so correctness is a yes/no question
about one record. That maps onto a binary `knitweb_vank` poll
(personhood-gated ballots, deterministic tally, auditable result) with the
fact's knit-CID as poll id.

**Continuous quantities** (crypto prices, cross-venue closes, model signals):
different honest observers legitimately report different numbers, so there is
no single CID to vote yes/no on. Floats never enter records — each observer
publishes their own scaled-integer observation fact — and vank supplies the
consensus: the weighted median over one observation per voter, with vank-style
non-negative fixed-point integer weights. The winning value is woven back as
a consensus fact whose ``derived_from`` lists every counted observation.

The pulse/vank runtimes are optional imports; the pure-math parts
(``weighted_median``, ``float_consensus``) are stdlib and always available.
"""
from __future__ import annotations

from typing import Iterable, Optional, Sequence

from finfacts.model import FinFact, Source

try:  # optional: pip install knitweb-vank (needs the pulse runtime)
    from knitweb_vank import Ballot, VbankKnitweb
    from knitweb_vank.poll import Poll, VbankPoll
    from knitweb_vank.tally import collect_ballots, tally

    HAS_VANK = True
except ImportError:  # pragma: no cover
    HAS_VANK = False

FACT_POLL_OPTIONS = 2  # 0 = incorrect, 1 = correct
CONSENSUS = Source(kind="finfield-consensus", ref="finknit.vote")


# -- exact facts: binary pulse/vank poll on one CID -------------------------

def fact_poll_id(knit_cid: str) -> str:
    return f"fact:{knit_cid}"


def open_fact_poll(authority_priv: str, scope: str, knit_cid: str,
                   opens_at: int, closes_at: int, quorum: int = 0):
    """Define a personhood-gated correct/incorrect poll for one woven fact.

    Returns the signed poll attestation; weave its record so peers can ballot.
    """
    if not HAS_VANK:
        raise ImportError("knitweb-vank is required for fact polls")
    poll = Poll(scope=scope, poll_id=fact_poll_id(knit_cid),
                options=FACT_POLL_OPTIONS, opens_at=opens_at,
                closes_at=closes_at, quorum=quorum)
    return VbankPoll(authority_priv, scope).define(poll)


def cast_ballot(web, voter_priv: str, ticket, scope: str, knit_cid: str,
                correct: bool, seq: int = 0, cast_at: int = 0):
    """Cast one personhood-gated correct/incorrect ballot on a woven fact.

    ``ticket`` is the voter's PersonhoodTicket for ``scope`` (pulse issues
    these); the ballot is signed with the holder's pairwise key and woven so
    every peer can independently re-tally. Returns (ballot_cid, attestation).
    Re-voting: cast again with a higher ``seq`` — the tally counts the
    highest seq per person.
    """
    if not HAS_VANK:
        raise ImportError("knitweb-vank is required to cast ballots")
    ballot = Ballot(scope=scope, poll_id=fact_poll_id(knit_cid),
                    choice=1 if correct else 0,
                    voter=ticket.holder_pairwise,
                    scope_nullifier=ticket.scope_nullifier,
                    seq=seq, cast_at=cast_at)
    return VbankKnitweb(scope).weave(ballot, ticket, voter_priv, web)


def fact_verdict(web, scope: str, knit_cid: str,
                 weights: Optional[dict] = None) -> Optional[bool]:
    """Deterministically tally the poll for one fact.

    True = confirmed correct, False = rejected, None = no ballots / tie.
    """
    if not HAS_VANK:
        raise ImportError("knitweb-vank is required for fact polls")
    poll_id = fact_poll_id(knit_cid)
    ballots = collect_ballots(web, scope, poll_id)
    if not ballots:
        return None
    result = tally(scope, poll_id, ballots, weights=weights)
    counts = dict(result["results"])  # [[choice, weight], ...] -> {choice: weight}
    no, yes = counts.get(0, 0), counts.get(1, 0)
    if yes == no:
        return None
    return yes > no


# -- continuous quantities: vank weighted-median value consensus ------------

def weighted_median(observations: Sequence[tuple[int, int]]) -> Optional[int]:
    """Weighted median of ``(value, weight)`` pairs — all integers.

    Weights follow the vank tally convention: non-negative fixed-point
    integers (one-observation-one-vote is weight 1). Deterministic: for an
    even split the lower middle value wins, so every node computes the same
    consensus. Returns None if total weight is zero.
    """
    rows = sorted((v, w) for v, w in observations if w > 0)
    total = sum(w for _, w in rows)
    if total == 0:
        return None
    acc = 0
    for value, weight in rows:
        acc += weight
        if 2 * acc >= total:
            return value
    return rows[-1][0]  # pragma: no cover


def float_consensus(observations: Iterable[FinFact],
                    weights: Optional[dict] = None) -> Optional[FinFact]:
    """Consensus fact for one continuous quantity from many observations.

    ``observations`` are per-voter observation facts for the *same*
    (entity, concept, unit, period). ``weights`` maps ``source.ref`` (the
    voter/observer id) to a vank fixed-point integer weight; absent means
    one-observation-one-vote. The winner is the weighted median at the
    finest observed scale, emitted as a ``finfield-consensus`` fact whose
    ``derived_from`` carries every counted observation CID.
    """
    obs = list(observations)
    if not obs:
        return None
    first = obs[0]
    for f in obs:
        if (f.entity_id, f.concept, f.unit, f.period) != (
                first.entity_id, first.concept, first.unit, first.period):
            raise ValueError("observations must target one (entity, concept, unit, period)")
    scale = max(f.scale for f in obs)
    pairs = []
    for f in obs:
        w = 1 if weights is None else int(weights.get(f.source.ref, 0))
        pairs.append((f.value * 10 ** (scale - f.scale), w))
    winner = weighted_median(pairs)
    if winner is None:
        return None
    return FinFact(
        entity_id=first.entity_id, concept=first.concept,
        value=winner, scale=scale, unit=first.unit, period=first.period,
        source=CONSENSUS,
        derived_from=tuple(sorted(f.cid for f, (_, w) in zip(obs, pairs) if w > 0)),
    )
