"""finknit — the FinField knitweb: weave financial facts P2P and vote on truth.

- plugin: the domain plugin (invariant-gated, signed, integer-only records)
  that knits FinFacts into the pulse fabric — anyone using the package can
  knit their own data in with their own key.
- vote: consensus on factual correctness — exact facts via personhood-gated
  pulse/vank polls; continuous (float-natured) quantities via vank
  weighted-median value consensus. Floats never enter records.
"""
from .plugin import (  # noqa: F401
    HAS_KNITWEB,
    KIND_ENTITY,
    KIND_FACT,
    FinFieldKnitweb,
    InvariantError,
    check_fact,
    from_record,
)
from .vote import (  # noqa: F401
    HAS_VANK,
    cast_ballot,
    fact_poll_id,
    fact_verdict,
    float_consensus,
    open_fact_poll,
    weighted_median,
)

__version__ = "0.1.0"
