"""FabricNode — a live p2p node that weaves into a fabric Web and converges.

A :class:`FabricNode` is the smallest useful "live web" peer: it owns a fabric
:class:`~knitweb.fabric.web.Web`, accepts local weaves, and **gossips every woven
record over the p2p transport** so that connected peers ingest the same records
into their own Web. Once a record has propagated, two nodes hold the *same set of
node CIDs and edges* and therefore the same :func:`~knitweb.fabric.items.web_state_root` —
they have **converged**.

This is the first increment of issue #9 (a live p2p fabric node). It deliberately
reuses the existing Phase-3 transport primitives rather than inventing a new one:

  * the canonical length-prefixed CBOR frames (:mod:`knitweb.p2p.wire`),
  * the static peer book + ``PeerAddress`` shape (:mod:`knitweb.p2p.node`),
  * the existing author signing (a feed keypair signs each broadcast record so a
    peer can verify provenance before weaving — equivocation-proofing of the feed
    history itself is left to the feed layer and a later increment).

Scope of this increment: **record propagation + convergence**.

  * ``weave(record)``      — weave locally *and* announce its CID to all peers.
  * ``sync_from(peer)``    — pull a peer's full record set (catch-up for a node
                             that joined after some records were already woven).
  * convergence            — after gossip/sync settles, ``state_root`` matches.

Conflict quarantine, partial proofs, and a real DHT are explicitly out of scope
here and continue to live in / evolve from the feed and ``AsyncioP2PNode`` layers.

Propagation is no longer a full-flood (#64): a weave **announces** the record's
canonical CID (``inv-announce``); each peer replies with only the CIDs it lacks
(``inv-getdata``); the announcer then serves those wants by sending the **stored
frame bytes verbatim** (``inv-data``), so a peer that already holds the CID never
receives the body — collapsing redundant traffic from O(N*body) to ~O(diff). The
:class:`~knitweb.p2p.inventory.InventoryRelay` drives the announce/want dedup; a
per-node ``CID -> verbatim signed-frame bytes`` store backs its ``FrameLookup``
so the served bytes — and therefore the record's CID — are byte-identical across
a hop. The unchanged ``sync_from`` / ``start_anti_entropy`` anti-entropy loop
remains the convergence backstop: anything a best-effort announce/want misses is
re-pulled by the periodic full sync, so every honest node still settles on the
identical ``web_state_root``.

Reconnect/periodic sync is no longer a full inv-announce flood either (#60 —
Erlay activation): :meth:`reconcile_with` drives a
:class:`~knitweb.p2p.reconcile.ReconcileSession` between this node's frame-store
CID set and a peer's, exchanging only compact ``(count, integer-xor-fingerprint)``
range summaries over the ``inv-recon-req`` / ``inv-recon-range`` /
``inv-recon-result`` envelopes. The recursive range bisection zeroes in on the
**symmetric difference** in traffic proportional to the *diff*, not the inventory;
the locally-missing CIDs it discovers are then fetched through the EXISTING
``inv-getdata`` path (stored frames served verbatim), so only ``|diff|`` bodies
travel — O(diff) instead of O(total). Reconciliation moves only CIDs and range
summaries, never a record body, so a signed record's byte-identity (and CID) is
untouched. Anti-entropy stays the unconditional convergence backstop: anything a
best-effort reconcile misses is still re-pulled by the periodic full sync.
"""

from __future__ import annotations

import asyncio
import random as _random_mod
from collections import deque

from ..core import canonical, crypto
from ..p2p.anti_entropy import SyncRound
from ..p2p.base_node import BaseNode
from ..p2p import inventory
from ..p2p.inventory import (
    INV,
    GETDATA,
    RECON_REQ,
    RECON_RANGE,
    RECON_RESULT,
    InventoryRelay,
)
from ..p2p import identity
from ..p2p.mesh import GRAFT, PRUNE, IHAVE, IWANT, Gossipsub
from ..p2p.policing import police_equivocation_report, police_invalid_proof
from ..p2p.reconcile import ReconcileSession
from ..p2p.wire import (
    WireError,
    equivocation_report_from_record,
    multiproof_from_record,
    multiproof_to_record,
)
from .equivocation import EquivocationReport
from .feed import FeedHead, _head_signable
from .feed_multiproof import _leaf, _levels, prove_range, verify_range_multiproof
from .items import web_state_root
from .web import Web
from ..p2p.node import PeerAddress, StaticPeerBook
from ..p2p.transport import Transport
from ..p2p import wire
from ..p2p.wire import WireError

DEFAULT_DIFFUSE_MAX_MS = 10

__all__ = ["FabricNode", "FabricNodeError", "WEB_TOPIC"]

# Domain-separation tag: a signature over a broadcast fabric record can never be
# replayed as a signature over a feed head, a Knit, or anything else.
_RECORD_TAG = b"knitweb/fabric-record/v1\x00"

# The single fixed gossipsub topic this increment maintains a mesh for. One web
# topic per fabric (Kademlia + Erlay topic-splitting are separate activations).
# Vocabulary stays Web/Knit/knitweb — never "loom"/"network".
WEB_TOPIC = "web/fabric/v1"

# Erlay activation (#60): the envelope key carrying a reconcile session id, so the
# RESPONDER can match a multi-round bisection's dials to one in-flight
# ReconcileSession. A plain integer-string in the dict carrier; it never touches a
# signed/hashed record body, so a Knit's CID is unaffected by its presence.
_RECON_SESSION_KEY = "session"

# Cap on concurrently-tracked responder reconcile sessions. A session is dropped
# the moment it converges, so honest load is tiny; this integer ceiling stops a
# peer from leaking unbounded session state. Oldest session is evicted on overflow.
_MAX_RECON_SESSIONS = 1024

# The node-layer key carrying the SENDER's stable gossip peer-id (its pubkey)
# alongside a mesh control frame. The mesh control frames themselves are ids-only
# (mesh.py is unedited); this envelope key lets the RECEIVER key its own mesh /
# score state on the announcer's stable ``node:<pubkey>`` rather than an
# ephemeral carrier id, exactly as #58 keys reputation. It is a plain string in
# the dict carrier and never touches a signed/hashed record body.
_MESH_PEER_KEY = "peer"


class FabricNodeError(RuntimeError):
    """Raised when the fabric gossip protocol refuses or cannot complete a request."""


def _record_signable(record: dict) -> bytes:
    """Canonical, domain-separated bytes an author signs to vouch for a record."""
    return _RECORD_TAG + canonical.encode(record)


def _is_edge_record(record: dict) -> bool:
    """True iff the SIGNED record is a fabric edge, read off signature-covered bytes.

    #163: the relay/sync ingest paths (sync_from / _pull_cids / _serve_inv_data)
    receive a stored envelope whose ``kind`` is OUTSIDE the author signature, so a
    relayer can flip ``fabric-record`` <-> ``fabric-edge`` on a validly-signed body
    and split the same CID across ``web.nodes`` and ``_out`` on different peers — a
    permanent state-root partition. The discriminator must therefore be derived
    from the SIGNED ``record`` itself.

    An edge body is exactly ``Edge.to_record()`` — ``kind == "edge"`` carrying the
    endpoint fields ``src``/``dst``/``rel`` (a ``weight`` int). ``kind`` is the
    first key inside ``canonical.encode(record)`` (and so inside
    :func:`_record_signable`), so a relayer cannot flip it without invalidating the
    author signature that ingest has already verified. No node schema
    (knowledge / resource / fabric-checkpoint / spatial-anchor / knitweb plugin
    kinds / ...) uses ``kind == "edge"``, so this predicate is exact for all honest
    traffic and tamper-evident for hostile relays. Pure-stdlib, integer-only, and
    reads existing signed bytes only — it adds/renames/reorders no field, so a
    record's canonical/signable bytes and CID are byte-identical.
    """
    if record.get("kind") != "edge":
        return False
    return (
        isinstance(record.get("src"), str)
        and isinstance(record.get("dst"), str)
        and isinstance(record.get("rel"), str)
    )


class FabricNode(BaseNode):
    """A live p2p fabric peer: a fabric Web plus record gossip + convergence.

    Each node has its own author keypair (a fresh secp256k1 key unless one is
    supplied). Records woven locally are signed and broadcast to every peer in
    the node's :class:`StaticPeerBook`; peers verify the author signature and
    weave the record into their own Web. Because :class:`Web.weave` is
    content-addressed and idempotent, gossip converges to an identical node set
    and edge set regardless of arrival order or duplicate delivery.
    """

    # The fabric _dispatch catches the fabric error family (plus wire/value).
    # Banned-branch frames_out: this node does NOT increment (diverges from
    # AsyncioP2PNode), preserving the existing gossip-path metric exactly.
    _dispatch_errors = (FabricNodeError, WireError, ValueError)
    _count_frames_out_on_banned = False

    def __init__(
        self,
        *,
        priv: str | None = None,
        host: str = "127.0.0.1",
        port: int = 0,
        transport: Transport | None = None,
        extra_transports: list[Transport] | None = None,
        gossip: Gossipsub | None = None,
        gossip_seed: int | None = None,
        serve_budget: "inventory.ServeBudget | None" = None,
        ingest_budget: "inventory.ServeBudget | None" = None,
        inv_probe_budget: "inventory.ServeBudget | None" = None,
        recon_budget: "inventory.ServeBudget | None" = None,
        max_gossiped_frames: int = 50_000,
        diffuse_max_ms: int = DEFAULT_DIFFUSE_MAX_MS,
        diffuse_seed: int | None = None,
        diffuse_sleep=None,
    ) -> None:
        super().__init__(
            host=host,
            port=port,
            transport=transport,
            extra_transports=extra_transports,
        )
        if priv is None:
            priv, _ = crypto.generate_keypair()
        self._priv = priv
        self.pub = crypto.public_from_private(priv)
        self.web = Web()
        self.peerbook = StaticPeerBook()
        # #91: the node's own APPEND-ONLY weave log (inner record dicts in local
        # arrival order) and per-server sync cursors. The log gives the record
        # SET a stable, feed-like coordinate system on THIS node, so a returning
        # peer can pull just entries[cursor:] under a range multiproof instead of
        # the whole snapshot. Local bookkeeping only — no canonical bytes change.
        self._sync_log: list[dict] = []
        self._sync_cursors: dict[str, int] = {}
        # #90: verified equivocation evidence, keyed by offending feed key — kept
        # OUTSIDE the web (evidence, not knowledge; it must not move the state
        # root) and re-servable so the ban propagates as portable proof.
        self.equivocation_reports: dict[str, EquivocationReport] = {}
        # The single load-bearing new piece for lazy relay (#64): a per-node
        # CID -> verbatim signed-envelope frame bytes store. The frame is the
        # exact ``write_frame_bytes`` of the ``fabric-record`` envelope we wove
        # or verified; serving these bytes UNCHANGED is what preserves a signed
        # record's byte-identity (and CID) across a relay hop. Populated on every
        # weave AND every successful ingest so a node can re-serve anything it
        # holds. It is node-local, integer-bounded by the relay's SeenSet, and
        # touches no canonical/hash path beyond storing already-canonical bytes.
        self._frames: dict[str, bytes] = {}
        # #92 frame-store bound. The store mixes two provenances with very different
        # eviction safety, so a blanket LRU is WRONG (it would silently drop our own
        # authoritative records — nothing on the web can re-serve them = data loss):
        #   * ``_authored`` — CIDs we wove ourselves; the authoritative source, NEVER
        #     evicted.
        #   * ``_gossiped_order`` — LRU queue of gossiped-in (non-authored) CIDs; only
        #     THIS portion is size-bounded, and evicting one is re-fetch-safe (anti-
        #     entropy / Erlay re-pull it). ``max_gossiped_frames`` caps it.
        self._authored: set[str] = set()
        self._gossiped_order: "deque[str]" = deque()
        self._max_gossiped = max(1, int(max_gossiped_frames))
        # A SEPARATE per-peer byte budget gates INGEST (a peer flooding own-key-signed
        # junk is throttled at _ingest_signed before it consumes memory — eviction
        # alone only caps steady-state). Reuses the #91 ServeBudget primitive (already
        # memory-bounded by its own max_peers LRU, injectable clock for tests).
        self._ingest_budget = (
            ingest_budget if ingest_budget is not None else inventory.ServeBudget()
        )
        # One inventory relay per node; its SeenSet is the announce/want dedup.
        # The lookup is into the frame store above (returns None for a CID we do
        # not hold, so on_getdata never fabricates a body). It also owns the #91
        # anti-amplification ServeBudget: a per-peer byte bucket over an integer
        # window plus a per-request batch cap, enforced on the getdata/IWANT serve
        # path so a single ~2 MiB request can no longer reflect hundreds of GiB.
        # A test injects ``serve_budget`` with a virtual clock so the window
        # boundary is deterministic; prod default uses a monotonic integer clock.
        self._serve_budget = (
            serve_budget if serve_budget is not None else inventory.ServeBudget()
        )
        self._inv = InventoryRelay(
            lambda cid: self._frames.get(cid), budget=self._serve_budget
        )
        # A SEPARATE per-peer budget gates the inv-announce REPLY path (#146). The
        # reply ``_serve_inv`` returns is a deterministic function of our holdings
        # (the announced CIDs we LACK come back as the want list), so a prober that
        # floods candidate CIDs reads out our exact held/lacked partition for free —
        # a holdings/membership oracle that the #91 getdata BYTE budget does not gate
        # (no body travels on this reply). We reuse the same ServeBudget primitive
        # but debit ONE token PER PROBED CID, capping CIDs-probed-per-peer-per-window:
        # an honest normal-volume announce stays under the cap and is answered
        # unchanged, while a mass-enumeration sweep exhausts the window and gets a
        # non-discriminating inv-ack (its partition is withheld). Its own max_peers
        # LRU bounds memory; a test injects a virtual clock for a deterministic
        # window. Separate from ``_serve_budget`` so honest body-serve and probe
        # accounting never starve each other.
        self._inv_probe_budget = (
            inv_probe_budget
            if inv_probe_budget is not None
            else inventory.ServeBudget(
                bytes_per_window=inventory.INV_PROBE_CIDS_PER_WINDOW
            )
        )
        # A SEPARATE per-peer budget gates the anti-entropy reconcile responder
        # (#159). Each reconcile probe costs O(in-range inventory) SHA-256 work, and
        # this was the one serve path with no debit — an 8 MiB request could carry
        # ~95k full-keyspace probes and burn minutes of CPU. We debit ONE token per
        # inbound reconcile FRAME before driving the session, so a near-synced honest
        # reconcile (a handful of O(diff) frames) is served unchanged while a probe
        # flood exhausts the window and is answered with an empty (converged) result
        # — the expensive hashing is never run. Same ServeBudget primitive as #91
        # (bytes) and #146 (probed CIDs); separate bucket so reconcile and body-serve
        # never starve each other. ``max_peers`` LRU bounds its memory.
        self._recon_budget = (
            recon_budget
            if recon_budget is not None
            else inventory.ServeBudget(
                bytes_per_window=inventory.RECON_FRAMES_PER_WINDOW
            )
        )
        # The per-peer serve key for the request currently being dispatched. Set by
        # the :meth:`_dispatch` override (from the carrier-stamped sender identity)
        # so the serve handlers can debit the right peer's byte bucket; ``None``
        # when the carrier could not identify the sender (the per-request count cap
        # still applies, so anonymity cannot bypass the hard ceiling).
        self._serve_peer_key: "str | None" = None
        # Erlay activation (#60): per-(peer, session) RESPONDER state. A reconcile
        # session is a multi-round bisection; on the one-shot dict carrier each
        # round is one dial, so the side being dialed must keep its
        # ReconcileSession alive across dials. Keyed on the session id the
        # initiator stamps. Bounded: a session is dropped as soon as it converges
        # (an empty reply batch) and the map is integer-capped so a peer cannot
        # leak unbounded sessions. The reconciler is socket/clock/RNG-free, so this
        # touches no signed record and no hash path.
        self._recon_sessions: dict[str, ReconcileSession] = {}
        # Monotonic integer session-id counter (initiator side). Deterministic and
        # injectable for tests via ``_recon_seq``; never a wall-clock/random value,
        # so a replayed reconcile mints identical session ids.
        self._recon_seq = 0
        # Background reconcile loop handle (issue #60), opt-in like anti-entropy /
        # gossip; stop() cancels it.
        self._reconcile_task: "asyncio.Task | None" = None
        # One gossipsub mesh for the single web topic (#67 activated on top of the
        # #75 inv->getdata propagation). It is purely a TARGET SELECTOR: it decides
        # WHICH peers a weave eager-pushes to (the bounded <=D mesh) and WHICH get
        # only a lazy IHAVE digest; it never moves a body. The peerbook NAME is the
        # gossip peer-id on the announce side; a peer keys ITS mesh state on the
        # sender's stable pubkey (carried in ``_MESH_PEER_KEY``). RNG/seed are
        # injected so a test replays a byte-identical mesh; prod gets a fresh
        # Random. The epoch is the integer the caller ticks via maintain_mesh().
        if gossip is not None:
            self._gossip = gossip
        else:
            self._gossip = Gossipsub(rng=_random_mod.Random(gossip_seed))
        # Source-privacy diffusion (#93). On the ORIGIN announce path only, each
        # mesh peer's already-built inv frame is dispatched after an independent
        # random integer-millisecond delay drawn uniformly over [0, diffuse_max_ms],
        # so the author is no longer deterministically the first emitter of its own
        # CID (the timing-correlation vector). The draw is INTEGER ms on a runtime
        # RNG — never the canonical byte path — so a fresh Knit CID and the stored
        # signed frame bytes are untouched at any setting. ``diffuse_max_ms == 0``
        # is exact legacy behaviour (no draw, no sleep) for tests/operators that
        # intentionally model the old path. The RNG is injected like the gossip RNG
        # above so tests replay deterministically; the sleep clock is injected like
        # start_anti_entropy so a test uses a virtual clock with no real wall-time.
        # The production default is non-zero: source privacy must be active unless
        # an operator explicitly disables it.
        self._diffuse_max_ms = max(0, int(diffuse_max_ms))
        self._diffuse_rng = _random_mod.Random(diffuse_seed)
        self._diffuse_sleep = diffuse_sleep if diffuse_sleep is not None else asyncio.sleep

    # -- server lifecycle -------------------------------------------------

    @property
    def state_root(self) -> str:
        """The Merkle root of this node's woven Web (the convergence witness)."""
        return web_state_root(self.web)

    async def _dispatch(self, msg: dict) -> dict:
        """Delegate to the shared dispatch, capturing the per-peer serve key.

        The #91 anti-amplification byte budget is keyed PER PEER, but the shared
        :meth:`BaseNode._dispatch` pops the carrier identity (and any piggybacked
        identity proof) and resolves the reputation key BEFORE it calls
        :meth:`_route`, so the serve handlers downstream would otherwise have no
        peer to debit. Rather than re-resolve (which would re-verify the same proof
        and trip the anti-replay seen-cache, downgrading the ban gate to carrier
        fallback), we let the base do its SINGLE resolution and hand us the verdict
        via :meth:`_note_serve_verdict`; the serve path then debits the IDENTICAL
        key the ban gate judged — the proven ``node:<pubkey>`` when a valid+fresh
        proof rode along (so a peer cannot dodge its budget by rotating carrier
        ids), else the carrier id, else ``None``. We never mutate ``msg`` and
        delegate verbatim, so every dispatch behaviour is byte-for-byte the base's.
        """
        try:
            return await super()._dispatch(msg)
        finally:
            # Scope the key to this dispatch only; never let it leak to the next.
            self._serve_peer_key = None

    def _note_serve_verdict(self, verdict) -> None:
        """Capture the base's ALREADY-RESOLVED verdict for the serve/ingest path.

        The base resolves the reputation key ONCE through the single identity gate
        (binding the OPTIONAL proof to the business body, recording it in the
        anti-replay seen-cache exactly once) and calls this hook before it routes,
        so the per-peer byte budget keys on the IDENTICAL key the ban gate judged:
        the proven ``node:<pubkey>`` when a valid+fresh+bound proof rode along, else
        the carrier id, else ``None``. Resolving here independently would re-verify
        the same proof and trip the seen-cache as a replay (downgrading the ban
        gate to carrier fallback), so we MUST reuse the base's single resolution.
        """
        self._serve_peer_key = verdict.rep_key if verdict is not None else None

    # -- self-healing anti-entropy (issue #44) ----------------------------

    def start_anti_entropy(
        self,
        peers: "list[PeerAddress] | None" = None,
        *,
        interval: int = 1,
        ceiling: int = 64,
        sleep=None,
    ) -> "asyncio.Task":
        """Launch the self-healing anti-entropy loop as a background task (#44).

        Opt-in: nothing runs until this is called, so a plain ``start()`` keeps
        its existing behaviour. The loop periodically re-pulls every peer's Web
        snapshot via :meth:`sync_from`, so a node that drifted apart after a
        disconnect re-converges on its peer's ``state_root`` once the peer is
        reachable again.

        ``peers`` are the endpoints to re-sync from (``None`` uses the configured
        peerbook). The injected clock defaults to :func:`asyncio.sleep` (the prod
        clock); a test passes a virtual-clock ``sleep`` so convergence is
        deterministic with no real time. The schedule is the integer backoff from
        #43. The driver swallows a failed round, so a dropped/refusing peer backs
        the schedule off rather than crashing the loop; on reconnect the next
        round re-syncs and the node re-converges.
        """
        return self._spawn_anti_entropy(
            self._anti_entropy_rounds(peers),
            interval=interval,
            ceiling=ceiling,
            sleep=sleep,
        )

    def _anti_entropy_rounds(
        self, peers: "list[PeerAddress] | None"
    ) -> "list[SyncRound]":
        async def sync_round() -> int:
            targets = (
                peers if peers is not None else list(self.peerbook.all().values())
            )
            if not targets:
                return 0
            pulled = 0
            reached = False
            for peer in targets:
                # A dropped/refusing peer raises here; swallow it so one bad peer
                # never sinks the round. If *every* peer raised the round itself
                # raises (below), and the driver backs the schedule off.
                try:
                    pulled += await self.sync_from(peer)
                except (OSError, FabricNodeError, WireError):
                    continue
                reached = True
            if not reached:
                # No peer was reachable this cycle: surface a failed round so the
                # driver escalates the backoff (it swallows the raise itself).
                raise FabricNodeError("no peer reachable for anti-entropy round")
            return pulled

        return [sync_round]

    # -- gossipsub mesh maintenance (issue #78) ---------------------------

    def start_gossip(
        self,
        *,
        interval: int = 1,
        sleep=None,
    ) -> "asyncio.Task":
        """Launch the gossipsub mesh-maintenance loop as a background task (#78).

        Opt-in, exactly like :meth:`start_anti_entropy`: nothing runs until this
        is called, so a plain ``start()`` keeps its existing behaviour and every
        existing test is unaffected. The loop ticks :meth:`maintain_mesh` (the
        GRAFT/PRUNE heartbeat that steers each topic mesh toward ``D``) then
        :meth:`gossip_tick` (the lazy mesh-IHAVE to non-mesh peers) once per
        ``interval``, so in a live node the mesh is actually maintained and the
        eager announce narrows from all-candidates to the bounded ``O(D)`` mesh.

        ``interval`` is an integer cadence (no wall-clock; the gossip heartbeat's
        own notion of time is its integer epoch). The injected ``sleep`` defaults
        to :func:`asyncio.sleep` (the prod clock); a test passes a virtual-clock
        ``sleep`` so the cadence is deterministic with no real time. A raised tick
        is swallowed (an offline peer this cycle) so one bad round never crashes
        the loop — the mesh re-steers on the next heartbeat. It touches no signed
        record and no hash path, so a woven Knit's CID is byte-identical whether
        or not this loop runs.
        """
        if not isinstance(interval, int) or isinstance(interval, bool):
            raise TypeError("interval must be int")
        if interval < 1:
            raise ValueError("interval must be >= 1")
        if self._gossip_task is not None and not self._gossip_task.done():
            return self._gossip_task
        self._gossip_task = asyncio.ensure_future(
            self._gossip_run(
                self._gossip_round,
                interval,
                sleep or self._gossip_sleep,
            )
        )
        return self._gossip_task

    async def _gossip_round(self) -> None:
        """One gossip heartbeat: maintain the mesh, then lazily gossip the fringe.

        The single tick the #78 scheduler drives: :meth:`maintain_mesh` advances
        the integer epoch and ships GRAFT/PRUNE to steer the mesh toward ``D``;
        :meth:`gossip_tick` then sends the lazy mesh-IHAVE digest to every
        non-mesh candidate. Both already swallow per-peer transport faults; this
        ordering is the one the mesh-propagation tests tick by hand.
        """
        await self.maintain_mesh()
        await self.gossip_tick()

    # -- Erlay reconcile (issue #60 activation) ---------------------------

    def _held_cids(self) -> list[str]:
        """This node's authoritative CID set: the verbatim frame-store keys.

        A CID is in the store iff this node holds the record's signed frame and can
        re-serve it byte-identically (populated on every weave AND every ingest).
        This is exactly the set a reconcile session bisects, and exactly the set
        the inv path serves from — so a CID the session flags as locally-missing is
        one ``inv-getdata`` can actually fetch.
        """
        return list(self._frames.keys())

    def start_reconcile(
        self,
        peers: "list[PeerAddress] | None" = None,
        *,
        interval: int = 1,
        sleep=None,
    ) -> "asyncio.Task":
        """Launch the periodic Erlay reconcile loop as a background task (#60).

        Opt-in, exactly like :meth:`start_anti_entropy` / :meth:`start_gossip`:
        nothing runs until this is called, so a plain ``start()`` keeps its
        existing behaviour and every existing test is unaffected. Each tick runs
        one :meth:`reconcile_tick`, which drives a :class:`ReconcileSession`
        against every peer and fetches ONLY the locally-missing CIDs via the
        existing ``inv-getdata`` path — O(diff) instead of an O(total) inv flood.

        ``interval`` is an integer cadence (no wall-clock). The injected ``sleep``
        defaults to :func:`asyncio.sleep`; a test passes a virtual-clock ``sleep``
        so the cadence is deterministic with no real time. A raised tick is
        swallowed (an offline peer this cycle) so one bad round never crashes the
        loop — the next tick re-reconciles, and anti-entropy remains the backstop.
        """
        if not isinstance(interval, int) or isinstance(interval, bool):
            raise TypeError("interval must be int")
        if interval < 1:
            raise ValueError("interval must be >= 1")
        if self._reconcile_task is not None and not self._reconcile_task.done():
            return self._reconcile_task
        self._reconcile_task = asyncio.ensure_future(
            self._gossip_run(
                lambda: self.reconcile_tick(peers),
                interval,
                sleep or self._gossip_sleep,
            )
        )
        return self._reconcile_task

    async def stop_reconcile(self) -> None:
        """Cancel the background reconcile loop if one is running."""
        task = self._reconcile_task
        self._reconcile_task = None
        if task is None or task.done():
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    async def stop(self) -> None:
        """Stop the listener and ALL background loops (adds reconcile to base).

        :class:`~knitweb.p2p.base_node.BaseNode.stop` tears down the anti-entropy
        and gossip loops; this override also cancels the opt-in reconcile loop
        (#60) before delegating, so a node started with :meth:`start_reconcile`
        shuts down just as cleanly as one started with the other loops.
        """
        await self.stop_reconcile()
        await super().stop()

    async def reconcile_tick(self, peers: "list[PeerAddress] | None" = None) -> int:
        """One reconcile heartbeat: reconcile with every peer; return CIDs fetched.

        Caller-driven (deterministic): a test ticks it explicitly; the #60 loop
        ticks it on its integer cadence; :meth:`sync_from`-style reconnect can call
        it directly. Per-peer transport faults are swallowed (an offline peer this
        cycle) so one bad peer never sinks the tick — the next tick retries and the
        anti-entropy backstop still converges that peer.
        """
        targets = peers if peers is not None else list(self.peerbook.all().values())
        fetched = 0
        for peer in targets:
            try:
                fetched += await self.reconcile_with(peer)
            except (OSError, FabricNodeError, WireError):
                continue
        return fetched

    async def reconcile_with(self, peer: PeerAddress) -> int:
        """Reconcile our CID set with ``peer`` and fetch ONLY the CIDs we lack.

        Drives a :class:`ReconcileSession` over the carrier: we open with a
        full-keyspace probe (``inv-recon-req``), then ping-pong compact
        ``(count, integer-xor-fingerprint)`` range summaries
        (``inv-recon-range`` <-> ``inv-recon-result``) until the bisection has
        zeroed in on the symmetric difference. The traffic is proportional to the
        *diff*, not the inventory: an identical CID set prunes at the root in a
        single round with zero CIDs exchanged.

        The session's ``missing`` set is exactly the CIDs the peer holds and we
        lack. We then issue ONE ``inv-getdata`` for precisely those CIDs; the peer
        serves them as ``inv-data`` (the verbatim stored frames), which we ingest
        through the same crypto gate as any other body — so byte-identity holds and
        only ``|diff|`` bodies ever travel. Returns the number of newly-woven
        records (``<= |missing|``).
        """
        session = ReconcileSession(self._held_cids())
        self._recon_seq += 1
        session_id = str(self._recon_seq)
        # 1) open: send the first probe batch as inv-recon-req.
        batch = session.open()
        kind = RECON_REQ
        while batch and not session.done:
            resp = await self._send(
                peer,
                {
                    "kind": kind,
                    _RECON_SESSION_KEY: session_id,
                    "frames": batch,
                },
            )
            rkind = resp.get("kind")
            if rkind == "error":
                raise FabricNodeError(f"{resp.get('code')}: {resp.get('message')}")
            if rkind != RECON_RESULT:
                raise FabricNodeError(f"unexpected reconcile response kind: {rkind!r}")
            reply = resp.get("frames")
            if not isinstance(reply, list):
                raise FabricNodeError("inv-recon-result frames must be a list")
            batch = session.advance([bytes(fr) for fr in reply])
            kind = RECON_RANGE
        self.metrics.incr("reconcile_sessions")
        # 2) fetch ONLY the locally-missing CIDs through the existing inv-getdata
        #    path: one getdata for exactly the symmetric-difference CIDs we lack.
        missing = sorted(session.missing)
        if not missing:
            return 0
        self.metrics.incr("reconcile_missing", len(missing))
        return await self._pull_cids(peer, missing)

    async def _pull_cids(self, peer: PeerAddress, cids: list[str]) -> int:
        """Fetch ``cids`` from ``peer`` via inv-getdata and ingest the bodies.

        The pull leg of the lazy relay: we dial an ``inv-getdata`` naming exactly
        the CIDs we lack, the peer replies ``inv-data`` carrying ONLY those bodies
        (its stored frames verbatim), and we ingest each through the SAME
        :meth:`_ingest_signed` crypto gate as a gossiped record — so a forged body
        is rejected identically and a valid one keeps its exact CID. Returns the
        number of newly-woven records.
        """
        if not cids:
            return 0
        resp = await self._send(peer, {"kind": GETDATA, "cids": cids})
        kind = resp.get("kind")
        if kind == "error":
            raise FabricNodeError(f"{resp.get('code')}: {resp.get('message')}")
        if kind != "inv-data":
            # The peer no longer holds those CIDs (or answered an ack); nothing to
            # ingest. Anti-entropy remains the backstop for that residue.
            return 0
        records = resp.get("records")
        if not isinstance(records, list):
            raise FabricNodeError("inv-data records must be a list")
        added = 0
        for item in records:
            if self._ingest_signed(item):
                added += 1
        if added:
            self.metrics.incr("reconcile_pulls", added)
        return added

    # -- peer wiring ------------------------------------------------------

    def add_peer(self, name: str, peer: PeerAddress) -> None:
        """Register a peer that local weaves will be broadcast to.

        The peerbook ``name`` doubles as this peer's gossipsub peer-id (the join
        key between the two layers): it is registered as a topic *candidate*, not
        a mesh member — :meth:`maintain_mesh` grafts candidates into the bounded
        mesh as degree requires. ``peerbook.all()`` is the name -> PeerAddress
        resolver that turns a mesh peer-id back into a dial target.
        """
        self.peerbook.add(name, peer)
        self._gossip.add_peer(WEB_TOPIC, name)

    # -- weaving + propagation --------------------------------------------

    async def weave(self, record: dict) -> str:
        """Weave ``record`` into the local Web and announce its CID to all peers.

        Returns the record's CID. Propagation is the lazy two-step relay (#64):
        we announce the canonical CID, each peer wants only what it lacks, and we
        serve the wanted bodies verbatim — so a peer that already holds the CID
        never receives the body. Per-peer failures are swallowed (a peer may be
        offline); convergence for such a peer is reached later by the unchanged
        anti-entropy / :meth:`sync_from` backstop. The signed-envelope frame is
        stored under the CID so the relay can serve it byte-identically.
        """
        before = len(self.web.nodes)
        cid = self.web.weave(record)
        if len(self.web.nodes) > before:
            self.metrics.incr("records_woven")
            self._sync_log.append(record)          # #91: authored records join the weave log
        # Store the verbatim signed-envelope frame bytes BEFORE announcing, so a
        # peer that wants this CID gets the exact bytes back (byte-identity). Marked
        # authored: our own records are authoritative and never evicted (#92).
        self._store_frame(cid, self._signed_record_msg(record), authored=True)
        await self._eager_announce(cid)
        return cid

    def _eager_targets(self, cid: str) -> list[str]:
        """The bounded set of peer NAMES this weave eager-pushes ``cid`` to.

        Delegates target selection to the gossipsub mesh (``publish`` returns the
        <=D mesh members for the topic, and records the id as held for future
        IHAVE digests). FALLBACK for tiny nets / a cold mesh: when the mesh is
        empty for the topic — which it is at construction before the first
        :meth:`maintain_mesh`, and whenever ``D >= peer-count`` keeps every
        candidate grafted — we announce to ALL candidates, so a weave issued
        immediately after ``add_peer`` (the convergence test's fan-out case) still
        gets the eager push and small nets behave byte-for-byte like #75. Once the
        mesh is non-empty the eager fan-out is bounded to O(D).
        """
        targets = self._gossip.publish(WEB_TOPIC, cid)
        if targets:
            return targets
        return self._gossip.topic_peers(WEB_TOPIC)

    async def link(self, src: str, dst: str, rel: str, weight: int = 1) -> str:
        """Create a signed link edge and announce it to peers for convergence.

        ``src`` and ``dst`` must already exist in the local web, matching
        :meth:`fabric.web.Web.link` semantics. Edges are treated as signed gossip
        objects so peers can converge on the same edge set, not just nodes.
        """
        if not isinstance(src, str) or not isinstance(dst, str) or not isinstance(rel, str):
            raise FabricNodeError("src/dst/rel must be strings")
        if not isinstance(weight, int) or isinstance(weight, bool) or weight < 0:
            raise FabricNodeError("weight must be a non-negative int")
        before_edges = len(self.web._out.get(src, []))
        edge = self.web.link(src, dst, rel, weight=weight)
        # Re-sign and store under the edge CID so peers can fetch the exact body
        # they can verify with the sender's key.
        self._store_frame(edge.cid, self._signed_edge_msg(edge.to_record()))
        # Announce only when the edge is truly new; duplicates are idempotent.
        if len(self.web._out.get(src, [])) > before_edges:
            await self._eager_announce(edge.cid)
            self.metrics.incr("edges_linked")
        return edge.cid

    async def _eager_announce(self, cid: str) -> None:
        """Announce ``cid`` to the MESH (not every peer); serve the bodies it lacks.

        Narrows the #75 eager path's target SET from ``peerbook.all()`` to the
        bounded gossipsub mesh (or all candidates as a cold-mesh fallback) while
        reusing :meth:`_announce_to` VERBATIM — so the inv -> getdata -> inv-data
        body transfer, the SeenSet dedup, and byte-identity are unchanged. Peers
        outside the mesh converge via the lazy IHAVE/IWANT tick and the unchanged
        anti-entropy backstop. The relay's :meth:`announce` returns ``None`` (and
        we skip the send) when the CID was already announced.
        """
        names = self._eager_targets(cid)
        frame = self._inv.announce([cid])
        if frame is None:
            return
        cids = inventory.parse_inv_frame(frame)
        self.metrics.incr("inv_announced", len(cids))
        peers = self._resolve_names(names)
        if not peers:
            return
        results = await asyncio.gather(
            *(self._diffused_announce_to(peer, cids) for peer in peers),
            return_exceptions=True,
        )
        # Swallow per-peer transport errors (offline peer); they are recoverable
        # via sync_from. Re-raise anything unexpected so bugs are not hidden.
        for result in results:
            if isinstance(result, Exception):
                if not isinstance(result, (OSError, FabricNodeError, WireError)):
                    raise result
                self.metrics.incr("broadcasts_failed")
            else:
                self.metrics.incr("broadcasts_sent")

    async def _diffused_announce_to(self, peer: PeerAddress, cids: list[str]) -> None:
        """Dispatch one peer's ORIGIN inv-announce after an independent diffusion delay.

        Source-privacy diffusion (#93), applied ONLY on the origin path
        (``weave``/``link`` -> :meth:`_eager_announce`). Each peer draws its OWN
        integer-millisecond delay over ``[0, self._diffuse_max_ms]`` (per call, so
        peers are independent), waits it out on the injected sleep clock, then runs
        the UNCHANGED :meth:`_announce_to` inv exchange. Because the delays are
        independent the author is the first announcer with probability ~``1/peers``
        rather than ~``1``, decorrelating announce order from origin.

        The drawn value stays an INTEGER millisecond count; the only division by
        1000 happens at the :func:`asyncio.sleep` boundary (seconds), never on the
        value path — so nothing float touches the canonical/byte path. When
        ``diffuse_max_ms == 0`` we neither draw nor sleep: behaviour is byte- and
        timing-identical to the legacy one-shot broadcast, which is what the
        byte-identity / interop suites assert. Diffusion gates only WHEN the dial
        starts; the #91/#102 ServeBudget still debits per-peer bytes inside
        :meth:`_announce_to` in the same order and count as before.
        """
        if self._diffuse_max_ms:
            delay_ms = self._diffuse_rng.randint(0, self._diffuse_max_ms)
            await self._diffuse_sleep(delay_ms / 1000)
        await self._announce_to(peer, cids)

    async def _announce_to(self, peer: PeerAddress, cids: list[str]) -> None:
        """Run the inv -> getdata -> inv-data exchange against one peer.

        Carrier model: each ``dial`` is one request map -> one response map, and
        every leg is announcer -> peer (so a pure-push topology where the peer has
        no route back to us still works — matching the convergence test, where a
        weaver knows its peers but the peers need not know the weaver).

          1. dial ``inv-announce`` -> peer replies ``inv-getdata`` (CIDs it lacks)
             or ``inv-ack`` (it has them all -> NO body travels: the O(diff) win).
          2. if it wanted any, dial ``inv-data`` carrying ONLY those bodies
             (stored frames verbatim), which the peer ingests.
        """
        resp = await self._send(peer, {"kind": INV, "cids": cids})
        kind = resp.get("kind")
        if kind == "error":
            raise FabricNodeError(f"{resp.get('code')}: {resp.get('message')}")
        if kind != GETDATA:
            # inv-ack (peer wanted nothing) or any non-want response: done. The
            # body was NOT sent — the whole point of the lazy relay.
            return
        wanted = resp.get("cids")
        if not isinstance(wanted, list):
            raise FabricNodeError("inv-getdata cids must be a list")
        # Serve exactly the wanted CIDs as verbatim stored frames, decoded to
        # their envelope maps to ride the dict carrier (canonical CBOR is
        # deterministic, so the inner record + its CID are byte-stable). The same
        # #91 outbound budget applies: when this push is itself answering an
        # inbound IWANT (``_serve_iwant_response``), ``_serve_peer_key`` names that
        # peer so its byte bucket is debited; on a locally-initiated eager weave it
        # is None and only the per-request count cap applies. Either way a serve
        # can never amplify past the fixed batch/byte ceiling.
        frames = self._inv.on_getdata(
            inventory.build_getdata_frame(wanted), peer=self._serve_peer_key
        )
        if not frames:
            return
        records = [wire.read_frame_bytes(fr) for fr in frames]
        self.metrics.incr("inv_served", len(records))
        ack = await self._send(peer, {"kind": "inv-data", "records": records})
        if ack.get("kind") == "error":
            raise FabricNodeError(f"{ack.get('code')}: {ack.get('message')}")

    # -- mesh maintenance + lazy gossip (issue #67 activation) ------------

    def _resolve_names(self, names: "list[str]") -> "list[PeerAddress]":
        """Resolve gossip peer NAMES back to dial targets via the peerbook.

        A name with no peerbook entry (e.g. a stale mesh id whose peer was
        removed) is silently skipped — the mesh is a target *hint*, never a
        source of truth about reachability.
        """
        book = self.peerbook.all()
        return [book[name] for name in names if name in book]

    async def maintain_mesh(self) -> None:
        """Tick one integer heartbeat epoch and ship the resulting GRAFT/PRUNE.

        Caller-driven (deterministic): a test ticks it explicitly; prod can
        piggyback the anti-entropy interval. :meth:`Gossipsub.heartbeat` advances
        the integer epoch and steers each topic mesh into ``[d_low, d_high]``,
        returning ``{name: [control frames]}``; we resolve each name to a dial
        target and push the GRAFT/PRUNE down the existing carrier (stamping our
        stable pubkey so the receiver keys ITS mesh on ``node:<pubkey>``). A peer
        offline this cycle is swallowed exactly like an eager-announce failure;
        the mesh re-steers next heartbeat. No wall-clock — the epoch is the only
        notion of time and it is an integer.
        """
        out = self._gossip.heartbeat([WEB_TOPIC])
        await self._ship_control(out)

    async def gossip_tick(self) -> None:
        """Send a lazy IHAVE digest to every NON-mesh candidate (the fringe path).

        A node in nobody's mesh receives no eager push; this is how it still
        learns held CIDs. We advertise the topic's held ids to each candidate that
        is NOT a current mesh member (mesh members already got the eager push). The
        peer answers the IHAVE *in the dial response* with an IWANT for the ids it
        lacks (no return route needed — fits the one-shot push carrier), and we
        serve exactly those via the unchanged inv getdata path, so bodies travel
        only through #75's verbatim frame store. Idempotent and bounded by the
        SeenSet at both ends.
        """
        frame = self._gossip.build_ihave(WEB_TOPIC)
        if frame is None:
            return
        mesh_members = set(self._gossip.mesh_peers(WEB_TOPIC))
        fringe = [n for n in self._gossip.topic_peers(WEB_TOPIC) if n not in mesh_members]
        book = self.peerbook.all()
        ihave = wire.read_frame_bytes(frame)
        ihave[_MESH_PEER_KEY] = self._mesh_self_id()
        for name in fringe:
            peer = book.get(name)
            if peer is None:
                continue
            try:
                resp = await self._send(peer, dict(ihave))
            except (OSError, FabricNodeError, WireError):
                continue
            await self._serve_iwant_response(peer, resp)

    async def _serve_iwant_response(self, peer: PeerAddress, resp: dict) -> None:
        """A fringe peer answered our IHAVE with an IWANT; serve it via inv-data.

        The IWANT names the CIDs the peer lacks; we push exactly those bodies
        through the EXISTING :meth:`_announce_to` inv path (verbatim stored
        frames), so the lazy fringe converges using the same byte-identical
        transfer as the eager mesh. A non-IWANT reply (peer already held
        everything) is a no-op.
        """
        if not isinstance(resp, dict) or resp.get("kind") != IWANT:
            return
        ids = resp.get("ids")
        if not isinstance(ids, list) or not ids:
            return
        try:
            await self._announce_to(peer, [str(c) for c in ids])
        except (OSError, FabricNodeError, WireError):
            self.metrics.incr("broadcasts_failed")

    async def _ship_control(self, out: "dict[str, list[bytes]]") -> None:
        """Push per-peer GRAFT/PRUNE control frames down the carrier.

        ``out`` is the ``{name: [frame bytes]}`` map :meth:`Gossipsub.heartbeat`
        returns. We decode each ids-only mesh frame to its dict, stamp our stable
        pubkey, and dial it. Per-peer failures are swallowed (offline peer); the
        mesh re-steers on the next heartbeat.
        """
        book = self.peerbook.all()
        for name, frames in out.items():
            peer = book.get(name)
            if peer is None:
                continue
            for fr in frames:
                msg = wire.read_frame_bytes(fr)
                msg[_MESH_PEER_KEY] = self._mesh_self_id()
                try:
                    await self._send(peer, msg)
                except (OSError, FabricNodeError, WireError):
                    continue

    def _signed_record_msg(self, record: dict) -> dict:
        sig = crypto.sign(self._priv, _record_signable(record))
        return {
            "kind": "fabric-record",
            "author": self.pub,
            "record": record,
            "sig": sig,
        }

    def _signed_edge_msg(self, record: dict) -> dict:
        sig = crypto.sign(self._priv, _record_signable(record))
        return {
            "kind": "fabric-edge",
            "author": self.pub,
            "record": record,
            "sig": sig,
        }

    def _store_frame(self, cid: str, envelope: dict, *, authored: bool = False) -> None:
        """Store the verbatim signed-envelope frame bytes for ``cid``.

        The frame is the canonical ``write_frame_bytes`` of the ``fabric-record``
        envelope. ``on_getdata`` returns these bytes UNCHANGED, so the inner
        record dict (and its CID) are byte-identical across a relay hop. Indexing
        is by ``canonical.cid(record)`` — the Web's own content address — never by
        a CID over the envelope (the envelope is re-signed per relayer by design).

        ``authored`` frames (our own weaves) are the authoritative source and are
        NEVER evicted; gossiped-in frames are tracked for LRU eviction and the
        non-authored portion is bounded at ``max_gossiped_frames`` (#92). Store
        management only — the bytes themselves stay verbatim, so byte-identity and
        the CID are untouched.
        """
        self._frames[cid] = wire.write_frame_bytes(envelope)
        if authored:
            self._authored.add(cid)
            return
        if cid in self._authored:
            return  # we also authored it — keep it un-evictable
        try:
            self._gossiped_order.remove(cid)  # re-store refreshes recency
        except ValueError:
            pass
        self._gossiped_order.append(cid)
        # Evict oldest non-authored frames over the cap (re-fetch-safe via anti-entropy).
        while len(self._gossiped_order) > self._max_gossiped:
            old = self._gossiped_order.popleft()
            if old in self._authored:
                continue  # defensive: never drop an authored frame
            self._frames.pop(old, None)

    def _id_signing_key(self) -> "str | None":
        """This node's author key signs its OPTIONAL piggybacked identity proofs.

        A FabricNode always holds a key, so its dials always carry a proof and a
        receiver keys reputation on this node's proven ``node:<pubkey>`` rather
        than its IP (step 2 of #58).
        """
        return self._priv

    async def _send(self, peer: PeerAddress, msg: dict) -> dict:
        # Routed by peer.transport (tcp:// or relay://); the carrier moves the
        # same opaque canonical-CBOR frame, so a signed record's bytes are
        # untouched whether it travels over a socket or the HTTP relay. We stamp
        # an OPTIONAL identity proof onto the outbound request (step 2 of #58) so
        # the receiver keys reputation on our proven node key, not our IP; the
        # proof rides in the stripped _relay_* envelope and never touches the
        # canonical frame bytes.
        return await self.dialer.dial(peer, self._stamp_id_proof(msg))

    # -- catch-up sync ----------------------------------------------------

    # #91: cap per range request so one reply frame stays bounded; a big catch-up
    # is simply several verified slices.
    SYNC_RANGE_CHUNK = 512

    async def sync_from(self, peer: PeerAddress) -> int:
        """Converge on ``peer``'s record set, pulling only what we are missing (#91).

        Negotiation: ask for the peer's signed weave-log head first. With a
        cursor from an earlier sync against the same peer key, only the log
        slice ``[cursor, length)`` is pulled — verified entry-by-entry against
        the signed head with a range multiproof, so an incremental catch-up
        costs O(missing + log n) bytes instead of O(total). A forged or stale
        slice penalises the serving key (``Offense.STALE_OR_FORGED_PROOF``) and
        aborts. Cold start (no cursor), an old peer that does not speak
        ``fabric-sync-head``, or a peer whose log shrank (should not happen —
        the log is append-only) all fall back to the full snapshot.

        Returns the number of newly woven records.
        """
        head_msg = await self._send(peer, {"kind": "fabric-sync-head"})
        head_raw = head_msg.get("head") if isinstance(head_msg, dict) else None
        if head_msg.get("kind") != "fabric-sync-head" or not isinstance(head_raw, dict):
            return await self._sync_full(peer)     # legacy peer — snapshot fallback
        try:
            head = FeedHead(feed=str(head_raw["feed"]), root=str(head_raw["root"]),
                            length=int(head_raw["length"]), fork=int(head_raw["fork"]),
                            sig=str(head_raw["sig"]))
        except (KeyError, TypeError, ValueError):
            return await self._sync_full(peer)
        if head.length > 0 and not head.verify():
            police_invalid_proof(self.reputation, head.feed)
            raise FabricNodeError("fabric sync head failed signature verification")
        if self.reputation.is_banned(head.feed):
            raise FabricNodeError("refusing to sync from a banned peer key")

        cursor = self._sync_cursors.get(head.feed, 0)
        if head.length == cursor:
            return 0                               # already converged — O(1) sync
        if cursor == 0 or cursor > head.length:
            added = await self._sync_full(peer)
            self._sync_cursors[head.feed] = head.length
            return added

        added = 0
        start = cursor
        while start < head.length:
            count = min(self.SYNC_RANGE_CHUNK, head.length - start)
            msg = await self._send(peer, {"kind": "fabric-sync-range",
                                          "start": start, "count": count})
            if msg.get("kind") != "fabric-sync-range-data":
                raise FabricNodeError(f"unexpected range response: {msg.get('kind')!r}")
            entries = msg.get("entries")
            if not isinstance(entries, list) or not all(isinstance(e, dict) for e in entries):
                raise FabricNodeError("fabric-sync-range-data entries must be maps")
            try:
                proof = multiproof_from_record(msg.get("proof"))
            except WireError as exc:
                raise FabricNodeError(f"bad range proof record: {exc}") from exc
            if not verify_range_multiproof(head, entries, proof) or proof.start != start:
                # provably wrong slice for the signed head — objective offense
                police_invalid_proof(self.reputation, head.feed)
                self.metrics.incr("sync_range_rejected")
                raise FabricNodeError("range slice failed multiproof verification")
            for record in entries:
                if self._ingest_proven(record):
                    added += 1
            self.metrics.incr("sync_range_verified")
            start += count
        self._sync_cursors[head.feed] = head.length
        if added:
            self.metrics.incr("sync_pulls", added)
        return added

    async def _sync_full(self, peer: PeerAddress) -> int:
        """The original full-snapshot pull — cold-start and legacy-peer fallback."""
        msg = await self._send(peer, {"kind": "fabric-sync-request"})
        if msg.get("kind") == "error":
            raise FabricNodeError(f"{msg.get('code')}: {msg.get('message')}")
        if msg.get("kind") != "fabric-sync-data":
            raise FabricNodeError(f"unexpected response kind: {msg.get('kind')!r}")
        signed = msg.get("records")
        if not isinstance(signed, list):
            raise FabricNodeError("fabric-sync-data records must be a list")
        added = 0
        for item in signed:
            if self._ingest_signed(item):
                added += 1
        if added:
            self.metrics.incr("sync_pulls", added)
        return added

    def _ingest_proven(self, record: dict) -> bool:
        """Weave a record whose provenance is a VERIFIED range multiproof (#91).

        The multiproof against the serving key's signed head replaces the
        per-record author signature the gossip path checks — same trust anchor
        as the snapshot fallback, whose envelopes are re-signed by that same
        serving key. Mirrors the #90 rules: evidence records are policed and
        never woven.
        """
        if not isinstance(record, dict):
            raise FabricNodeError("proven record must be a map")
        if record.get("kind") == "equivocation-report":
            self._police_report_record(record)
            return False
        is_edge = _is_edge_record(record)
        before_nodes = len(self.web.nodes)
        before_edges = len(self.web._out.get(record.get("src"), []))
        if is_edge:
            src, dst, rel = record.get("src"), record.get("dst"), record.get("rel")
            weight = record.get("weight", 1)
            if not isinstance(src, str) or not isinstance(dst, str) or not isinstance(rel, str):
                raise FabricNodeError("fabric edge record missing src/dst/rel")
            if not isinstance(weight, int) or isinstance(weight, bool) or weight < 0:
                raise FabricNodeError("fabric edge weight must be a non-negative int")
            if src not in self.web.nodes or dst not in self.web.nodes:
                return False
            edge = self.web.link(src, dst, rel, weight=weight)
            cid = edge.cid
            created = len(self.web._out.get(src, [])) > before_edges
        else:
            cid = canonical.cid(record)
            self.web.weave(record)
            created = len(self.web.nodes) > before_nodes
        frame = self._signed_edge_msg(record) if is_edge else self._signed_record_msg(record)
        self._store_frame(cid, frame)
        self._inv.on_record(cid)
        if created:
            self.metrics.incr("records_woven")
            self._sync_log.append(record)
            return True
        return False

    # -- ingestion --------------------------------------------------------

    def _police_report_record(self, record: dict) -> bool:
        """Verify a gossiped equivocation report from its bytes; ban on success (#90).

        Structural parse errors and unverifiable reports are IGNORED (never a
        penalty on hearsay — mirroring ``police_equivocation_report``); a report
        that verifies bans ``report.offender`` in the shared reputation ledger,
        is kept in :attr:`equivocation_reports` as portable evidence, and bumps
        the ``equivocations_detected`` metric.
        """
        try:
            report = equivocation_report_from_record(record)
        except WireError:
            return False
        if not police_equivocation_report(self.reputation, report):
            return False
        self.equivocation_reports[report.offender] = report
        self.metrics.incr("equivocations_detected")
        return True

    def _ingest_signed(self, item, *, is_edge: "bool | None" = None) -> bool:
        """Verify an author-signed record envelope and weave it. True if new.

        Routing (node vs edge) must be decided by SIGNATURE-COVERED content so one
        signed body cannot be a NODE on one peer and an EDGE on another — a durable
        state-root partition anti-entropy can never heal. The gossip routing table
        (:meth:`_route`) passes the envelope kind it matched via ``is_edge`` and
        that explicit path is honoured unchanged (#144). When ``is_edge`` is
        omitted (relay/sync ingest of a stored envelope: ``sync_from`` /
        :meth:`_pull_cids` / :meth:`_serve_inv_data`) the envelope ``kind`` is
        OUTSIDE the author signature, so a relayer can flip it; we therefore derive
        the discriminator from the verified inner ``record`` itself via
        :func:`_is_edge_record` (#163), which reads the signed ``kind``/endpoint
        bytes a relayer cannot alter without breaking the signature already
        verified above. No signed bytes are added or changed — CIDs are untouched.
        """
        if not isinstance(item, dict):
            raise FabricNodeError("record envelope must be a map")
        author = item.get("author")
        record = item.get("record")
        sig = item.get("sig")
        if not isinstance(author, str) or not isinstance(sig, str):
            raise FabricNodeError("record envelope missing author/sig")
        if not isinstance(record, dict):
            raise FabricNodeError("record must be a map")
        if not crypto.verify(author, _record_signable(record), sig):
            raise FabricNodeError("invalid author signature on fabric record")
        # ── #90 equivocation quarantine ─────────────────────────────────────
        # A signed ``equivocation-report`` record is EVIDENCE, not knowledge: it is
        # verified from its own bytes and policed (Offense.EQUIVOCATION is a full-
        # threshold ban on the offending feed key), stored for re-gossip, and NOT
        # woven — evidence must never move the web state root. Honest fork-bumped
        # rewrites can never verify as a report (check_conflict requires the same
        # fork), so legitimate truncate-and-rewrite is structurally exempt.
        if record.get("kind") == "equivocation-report":
            self._police_report_record(record)
            return False
        # Records authored by a key with a PROVEN equivocation are quarantined:
        # refused without weaving (no exception — the relaying peer is innocent;
        # the offense already landed on the author's key via the report).
        if self.reputation.is_banned(author):
            self.metrics.incr("records_quarantined")
            return False
        if is_edge is None:
            # #163: route on the SIGNED record, never the relayer-controlled,
            # UNSIGNED envelope item['kind'] — that flip re-opened the partition.
            is_edge = _is_edge_record(record)
        # #92 ingest admission: a peer flooding (validly) own-key-signed junk is throttled
        # HERE — before the record lands in the web or the frame store, so a flood is
        # capped at ingest rather than merely evicted after it has consumed memory.
        # Verify ran first (forged sigs still raise → ban-gate penalty); the dropped valid
        # record is re-fetch-safe (anti-entropy re-delivers when the peer's window refills).
        peer = self._serve_peer_key
        if peer is not None:
            size = len(wire.write_frame_bytes(item))
            if self._ingest_budget.take(peer, size) < size:
                self.metrics.incr("ingest_throttled")
                return False
        before_nodes = len(self.web.nodes)
        before_edges = len(self.web._out.get(record.get("src"), []))
        if is_edge:
            src = record.get("src")
            dst = record.get("dst")
            rel = record.get("rel")
            weight = record.get("weight", 1)
            if not isinstance(src, str) or not isinstance(dst, str) or not isinstance(rel, str):
                raise FabricNodeError("fabric edge envelope missing src/dst/rel")
            if not isinstance(weight, int) or isinstance(weight, bool):
                raise FabricNodeError("fabric edge weight must be an int")
            if weight < 0:
                raise FabricNodeError("fabric edge weight must be non-negative")
            if src not in self.web.nodes or dst not in self.web.nodes:
                cid = canonical.cid(record)
                created = False
            else:
                edge = self.web.link(src, dst, rel, weight=weight)
                cid = edge.cid
                created = len(self.web._out.get(src, [])) > before_edges
        else:
            cid = canonical.cid(record)
            self.web.weave(record)
            created = len(self.web.nodes) > before_nodes

        # Store the verbatim envelope frame for this CID so a node that learned a
        # record by relay/sync can re-serve it byte-identically (the FrameLookup
        # backing store must be populated on ingest, not just on weave — else
        # on_getdata returns None and that peer relies on the anti-entropy
        # backstop). Re-sign under our key on serve happens via _signed_record_msg
        # in weave; here we keep the exact verified envelope bytes.
        self._store_frame(cid, item)
        # Mark the CID seen in the relay so a later inv does not re-want it.
        self._inv.on_record(cid)
        if created:
            self.metrics.incr("records_woven")
            self._sync_log.append(record)          # #91: every newly woven record joins the log
            return True
        return False

    # -- server side ------------------------------------------------------

    def _sync_head(self) -> FeedHead:
        """A signed commitment to this node's weave log (#91): FeedHead semantics
        with feed = our node key, root = the Merkle root over the log's record
        leaves, length = log size, fork = 0 (the log is append-only by
        construction — records are only ever appended when newly woven)."""
        leaves = [_leaf(e) for e in self._sync_log]
        root = _levels(leaves)[-1][0].hex() if leaves else ""
        n = len(self._sync_log)
        sig = crypto.sign(self._priv, _head_signable(self.pub, root, n, 0))
        return FeedHead(feed=self.pub, root=root, length=n, fork=0, sig=sig)

    def _serve_sync_head(self) -> dict:
        h = self._sync_head()
        return {"kind": "fabric-sync-head",
                "head": {"feed": h.feed, "root": h.root, "length": h.length,
                         "fork": h.fork, "sig": h.sig}}

    def _serve_sync_range(self, msg: dict) -> dict:
        start = msg.get("start")
        count = msg.get("count")
        if not isinstance(start, int) or not isinstance(count, int) or isinstance(start, bool) or isinstance(count, bool):
            return {"kind": "error", "code": "bad-range", "message": "start/count must be ints"}
        n = len(self._sync_log)
        if count <= 0 or start < 0 or start + count > n:
            return {"kind": "error", "code": "bad-range",
                    "message": f"range [{start},{start + count}) out of bounds for {n}"}
        proof = prove_range(self._sync_log, start, count)
        h = self._sync_head()
        return {"kind": "fabric-sync-range-data",
                "entries": [dict(e) for e in self._sync_log[start:start + count]],
                "proof": multiproof_to_record(proof),
                "head": {"feed": h.feed, "root": h.root, "length": h.length,
                         "fork": h.fork, "sig": h.sig}}

    def _serve_sync(self) -> dict:
        # Re-sign every node we hold under *our* key so a catching-up peer can
        # verify provenance of the snapshot it pulls. (Records keep their own
        # CID identity regardless of who relays them.)
        records = [self._signed_record_msg(rec) for rec in self.web.nodes.values()]
        edges = []
        for src in sorted(self.web.nodes):
            for edge in sorted(self.web._out.get(src, []), key=lambda e: (e.rel, e.dst, e.weight)):
                edges.append(self._signed_edge_msg(edge.to_record()))
        records.extend(edges)
        return {"kind": "fabric-sync-data", "records": records}

    def _route(self, kind, msg: dict, source_id: "str | None" = None) -> dict:
        """Fabric routing table: ingest a gossiped record, or serve a sync snapshot.

        (``source_id`` is accepted for the shared :meth:`BaseNode._dispatch` signature; the
        fabric node does no PEX, so it is unused — the #94 source-group keying lives in
        :class:`~knitweb.p2p.node.AsyncioP2PNode`.)

        A forged author signature raises ``FabricNodeError("invalid author
        signature ...")`` here; the shared :meth:`BaseNode._dispatch` catches it,
        charges the relaying peer an :class:`Offense.INVALID_SIGNATURE` penalty
        (the message carries the word "signature"), and refuses — so the offense
        lands uniformly on the live TCP path and the relay path alike (#52), with
        no node-specific ``_serve_connection`` override to keep in sync.
        """
        if kind in ("fabric-record", "fabric-edge"):
            # Content-authoritative routing (#167): the SIGNED record shape is the
            # single authority on EVERY carrier. The gossip envelope ``kind``
            # (``fabric-record`` / ``fabric-edge``) is OUTSIDE the author
            # signature, so a relayer — or a self-signing remote — can deliver the
            # identical signed body under either envelope. Routing on the envelope
            # here (the #144 ``is_edge=False`` branch) filed an edge-shaped body as
            # a NODE, while the relay/sync seam (``_serve_inv_data`` / ``_pull_cids``
            # / ``sync_from``) files it as an EDGE by content — so two honest peers
            # held a permanently divergent ``web_state_root`` for one CID. Passing
            # ``is_edge=None`` lets :func:`_is_edge_record` read the signature-
            # covered ``kind``/endpoint bytes, exactly as the relay/sync seam does,
            # so the same body files the same way on every path and every receiver
            # agrees with the author (who files by content via weave/link). A
            # legit node record never carries ``kind=='edge'`` and a legit edge
            # body is exactly ``Edge.to_record()``, so no honest record is
            # misfiled. No signed bytes change — the CID is untouched.
            self._ingest_signed(msg)
            return {"kind": "fabric-ack"}
        elif kind == "fabric-sync-request":
            return self._serve_sync()
        elif kind == "fabric-sync-head":
            return self._serve_sync_head()
        elif kind == "fabric-sync-range":
            return self._serve_sync_range(msg)
        elif kind == INV:
            return self._serve_inv(msg)
        elif kind == GETDATA:
            return self._serve_getdata(msg)
        elif kind == "inv-data":
            return self._serve_inv_data(msg)
        elif kind in (RECON_REQ, RECON_RANGE):
            return self._serve_recon(kind, msg)
        elif kind in (GRAFT, PRUNE, IHAVE, IWANT):
            return self._serve_mesh(kind, msg)
        return {"kind": "error", "code": "unknown-kind", "message": str(kind)}

    # -- gossipsub mesh control server side (issue #67) -------------------

    def _mesh_peer_id(self, asserted) -> "str | None":
        """Resolve the mesh candidate id for the request currently being served.

        Fix for #143 (mesh peer-id auth: unbounded candidate growth + sybil
        eclipse). The ``_MESH_PEER_KEY`` field an inbound mesh frame carries is a
        plain, UNSIGNED, UNVERIFIED body field: it is not bound to the carrier and
        not bound to any proven identity, so trusting it to key the mesh/score
        state lets ONE carrier mint a fresh fabricated peer-id per request. Each
        such id permanently grows both ``_scores`` and ``_topic_peers`` (neither is
        capacity-bounded), and a fresh id starts at score 0, so 12 distinct
        fabricated ids from one connection saturate the mesh and eclipse honest
        GRAFTs. We therefore mirror the proven-vs-asserted identity pattern (#94 /
        #100) and key the mesh candidate on the ALREADY-RESOLVED dispatch identity
        (``_serve_peer_key``: the proven ``node:<pubkey>`` when a valid+fresh
        identity proof rode along, else the carrier id) rather than the asserted
        field:

          * a proof rode along (a real verified ``node:<pubkey>``): REQUIRE the
            asserted id to be that same proven identity, else IGNORE the frame —
            a forged ``_MESH_PEER_KEY`` can never mint a candidate;
          * no proof, but the carrier is identified: collapse to the carrier id, so
            ALL fabricated ids from one connection map to ONE mesh candidate;
          * neither (an unidentified stub carrier, e.g. in-process tests): fall
            back to the asserted id — there is no connection to collapse on and the
            asserted id is the only available stable handle.

        No new crypto, no change to ``mesh.py``'s ``add_peer``/``on_graft``
        signatures, and no signed-record/CID bytes touched: this is a serve-path
        keying decision, local to the fabric serve handler.
        """
        proven = self._serve_peer_key
        if proven is None:
            return asserted
        if proven.startswith(identity.NODE_PEER_PREFIX):
            # A proof rode along: the proven node id is the authority. An honest
            # GRAFT asserts that same proven id; anything else is a forgery -> drop.
            return proven if asserted == proven else None
        # Identified carrier, no proof: collapse every asserted id to the carrier.
        return proven

    def _mesh_self_id(self) -> str:
        """This node's OWN authenticated mesh peer-id to stamp on outbound frames.

        The companion to :meth:`_mesh_peer_id`. A FabricNode always dials with a
        piggybacked identity proof (:meth:`_id_signing_key`), so a receiver over an
        identified carrier resolves our ``_serve_peer_key`` to our proven
        ``node:<pubkey>`` (#89, the unlinkable identity pubkey). We must therefore
        ASSERT that very id in ``_MESH_PEER_KEY`` so the receiver's #143 binding
        check (``asserted == proven``) admits our genuine GRAFT instead of dropping
        it. A keyless node (no identity key) has no proof to ride, so it falls back
        to its plain pubkey, which the receiver only consults when no carrier id
        could identify the connection. Derives the SAME identity pubkey the proof
        proves; no new key material and nothing reaches a signed/hashed record body.
        """
        proof_key = self._id_network_signing_key()
        if proof_key is None:
            return self.pub
        return identity.node_peer_id(crypto.public_from_private(proof_key))

    def _serve_mesh(self, kind, msg: dict) -> dict:
        """Handle an inbound mesh control frame, delegating to the unchanged mesh.

        Mesh frames carried over the dict carrier ride an extra ``_MESH_PEER_KEY``
        naming the SENDER's asserted gossip peer-id. We do NOT trust that field to
        key state: it is unsigned and unbound, so :meth:`_mesh_peer_id` rebinds the
        candidate to the proven dispatch identity (or the carrier id) per #143
        before registering it as a topic candidate (so reciprocal GRAFT/PRUNE/score
        state keys on the stable, authenticated id, never an ephemeral or forged
        one — #58/#143). We then strip the key and re-encode the ids-only frame
        bytes mesh.py expects. mesh.py is reused UNEDITED; no record body ever rides
        a mesh frame, so byte-identity is preserved trivially.

          * GRAFT -> :meth:`Gossipsub.on_graft` (bounce a PRUNE or accept).
          * PRUNE -> :meth:`Gossipsub.on_prune`.
          * IHAVE -> :meth:`Gossipsub.on_ihave`: reply an IWANT for ids we lack,
            so the announcer serves them via the inv path IN-BAND on this round
            trip (the fringe pull). No body travels in this response.
          * IWANT -> :meth:`Gossipsub.on_iwant`: return a GETDATA of the held ids
            so the body moves through the EXISTING inv getdata path verbatim.
        """
        asserted = msg.get(_MESH_PEER_KEY)
        if not isinstance(asserted, str) or not asserted:
            raise FabricNodeError("mesh control frame missing peer id")
        sender = self._mesh_peer_id(asserted)
        if sender is None:
            # Forged peer-id over a proven carrier: refuse to mint a candidate.
            return {"kind": "mesh-ack"}
        frame = wire.write_frame_bytes({k: v for k, v in msg.items() if k != _MESH_PEER_KEY})
        # Make the AUTHENTICATED candidate known so on_graft/score state keys on it.
        self._gossip.add_peer(WEB_TOPIC, sender)
        if kind == GRAFT:
            reply = self._gossip.on_graft(sender, frame)
            if reply is None:
                return {"kind": "mesh-ack"}
            bounce = wire.read_frame_bytes(reply)
            bounce[_MESH_PEER_KEY] = self._mesh_self_id()
            return bounce
        if kind == PRUNE:
            self._gossip.on_prune(sender, frame)
            return {"kind": "mesh-ack"}
        if kind == IHAVE:
            want = self._gossip.on_ihave(sender, frame)
            if want is None:
                return {"kind": "mesh-ack"}
            return wire.read_frame_bytes(want)
        # IWANT: return the held ids as a getdata so the sender serves the bodies
        # through the inv path. We hold them in the frame store keyed by CID.
        ids = self._gossip.on_iwant(sender, frame)
        if not ids:
            return {"kind": "mesh-ack"}
        return {"kind": GETDATA, "cids": ids}

    # -- inventory (lazy relay) server side (#64) -------------------------

    def _serve_inv(self, msg: dict) -> dict:
        """Handle an inbound ``inv-announce``: reply with the CIDs we lack.

        Diffs the announced CIDs against our frame store AND the relay SeenSet via
        :meth:`InventoryRelay.on_inv`. Returns an ``inv-getdata`` naming exactly
        the CIDs we want (so the announcer sends only those bodies), or an
        ``inv-ack`` when we already hold everything — in which case NO body ever
        travels (the O(diff) collapse). A malformed inv frame raises
        ``InventoryError`` (a ``ValueError`` subclass), which the shared
        ``_dispatch`` maps to a ``bad-request`` with no new error wiring.

        Holdings-oracle defense (#146): the want list is a deterministic function
        of our holdings (the announced CIDs we LACK come back; the rest we hold),
        so an unbudgeted reply lets a prober enumerate our exact held/lacked
        partition by announcing arbitrary candidate CIDs. We therefore debit ONE
        token per probed CID from the per-peer :attr:`_inv_probe_budget` (the same
        ServeBudget primitive as #91, here counting CIDs not bytes). While the peer
        is within its CIDs-per-window budget the reply is computed and served as
        before, so an honest normal-volume announce is unchanged. Once the peer
        exhausts the window — a mass-enumeration sweep — we withhold the
        discriminating answer and return a non-informative ``inv-ack`` (as if we
        held everything): the prober learns nothing about the over-budget CIDs, so
        it can no longer cheaply read out the full holdings set. ``_serve_peer_key``
        of ``None`` (an unidentifiable carrier) shares one bucket, so anonymity
        cannot bypass the cap. This is a serve-path budgeting decision only — no inv
        wire frame, signed-record body, or canonical/CID byte is touched.
        """
        cids = msg.get("cids")
        if not isinstance(cids, list):
            raise FabricNodeError("inv-announce cids must be a list")
        peer = self._serve_peer_key if self._serve_peer_key is not None else "_anon"
        want = len(cids)
        if want and self._inv_probe_budget.take(peer, want) < want:
            # Probe budget exhausted this window: withhold the held/lacked partition
            # for this (over-budget) announce. We still mark the announced CIDs seen
            # via on_inv so dedup/recency state stays consistent, but reply with a
            # non-discriminating inv-ack instead of the want list, so the prober
            # cannot read our holdings out of the response.
            self._inv.on_inv(inventory.build_inv_frame(cids))
            self.metrics.incr("inv_probe_throttled")
            return {"kind": "inv-ack"}
        want_frame = self._inv.on_inv(inventory.build_inv_frame(cids))
        if want_frame is None:
            return {"kind": "inv-ack"}
        wanted = inventory.parse_getdata_frame(want_frame)
        self.metrics.incr("inv_wanted", len(wanted))
        return {"kind": GETDATA, "cids": wanted}

    def _serve_inv_data(self, msg: dict) -> dict:
        """Handle an inbound ``inv-data``: ingest the served record envelopes.

        Each envelope flows through the same :meth:`_ingest_signed` crypto gate as
        a ``fabric-record`` or a ``fabric-sync-data`` item, so a forged body served
        via the lazy path is rejected identically — the Byzantine tests are
        unaffected. Ingest stores the verbatim frame and marks the relay seen.
        """
        records = msg.get("records")
        if not isinstance(records, list):
            raise FabricNodeError("inv-data records must be a list")
        for item in records:
            self._ingest_signed(item)
        return {"kind": "inv-ack"}

    def _serve_getdata(self, msg: dict) -> dict:
        """Handle an inbound ``inv-getdata`` (the reconcile PULL leg): serve bodies.

        A reconciling peer that discovered it lacks some CIDs dials this with the
        exact symmetric-difference CIDs it wants. We return an ``inv-data`` carrying
        ONLY those bodies — the **stored frame bytes verbatim** via
        :meth:`InventoryRelay.on_getdata`, decoded to their envelope maps to ride
        the dict carrier — so the served bytes (and each record's CID) are
        byte-identical, and a CID we do not hold is silently skipped (never
        fabricated). This is the inverse direction of the eager :meth:`_announce_to`
        push: there WE serve after announcing; here the peer pulls exactly its diff.
        """
        cids = msg.get("cids")
        if not isinstance(cids, list):
            raise FabricNodeError("inv-getdata cids must be a list")
        # Serve under the #91 per-peer outbound budget: at most MAX_GETDATA_BATCH
        # bodies, and at most the requesting peer's remaining bytes/window. The
        # peer key is the one this dispatch resolved (proven node id when a proof
        # rode along, else carrier id, else None -> count-cap-only). Un-served CIDs
        # are re-requested next reconcile round (O(remaining-diff)), so an honest
        # large diff still converges across windows; a pathological whole-inventory
        # pull is capped here instead of reflecting hundreds of GiB.
        frames = self._inv.on_getdata(
            inventory.build_getdata_frame(cids), peer=self._serve_peer_key
        )
        if not frames:
            return {"kind": "inv-ack"}
        records = [wire.read_frame_bytes(fr) for fr in frames]
        self.metrics.incr("inv_served", len(records))
        return {"kind": "inv-data", "records": records}

    # -- Erlay reconcile server side (issue #60) --------------------------

    def _serve_recon(self, kind, msg: dict) -> dict:
        """Handle an inbound reconcile batch: drive the RESPONDER session, reply.

        A reconcile session is a multi-round bisection; on the one-shot carrier
        each round is one dial, so we keep a :class:`ReconcileSession` alive per
        session id (stamped by the initiator in ``_RECON_SESSION_KEY``). On the
        OPENING batch (``inv-recon-req``) we create the session over our current
        held CID set; on each batch we feed its frames to the session and reply with
        the frames it produced. An empty reply means we pruned/answered every range
        — the session has converged — so we drop it (bounded state). Only range
        summaries and CID lists ride these envelopes; no record body, so a signed
        record's byte-identity is untouched. The reply is an ``inv-recon-result``.
        """
        session_id = msg.get(_RECON_SESSION_KEY)
        if not isinstance(session_id, str) or not session_id:
            raise FabricNodeError("reconcile frame missing session id")
        # Validate the inbound batch off the wire — enforce MAX_RECON_FRAMES so an
        # 8 MiB envelope can't smuggle ~95k probes past the per-probe O(inventory)
        # hashing (#159). InventoryError (a ValueError) maps to bad-request.
        batch = inventory.parse_recon_batch(msg.get("frames"))
        # Anti-amplification: debit the per-peer reconcile budget BEFORE driving the
        # session (the costly hashing). Over budget ⇒ withhold the work and return an
        # empty result, which cleanly ends the round on the initiator side; honest
        # near-synced sessions stay well under the cap and are served unchanged. An
        # unidentifiable carrier shares one ``_anon`` bucket so anonymity can't bypass
        # the ceiling.
        nframes = len(batch)
        if nframes:
            peer = self._serve_peer_key if self._serve_peer_key is not None else "_anon"
            if self._recon_budget.take(peer, nframes) < nframes:
                self.metrics.incr("recon_throttled")
                return {"kind": RECON_RESULT, "frames": []}
        if kind == RECON_REQ:
            # A fresh request opens a new responder session over our held CIDs. Cap
            # the session table so a peer cannot leak unbounded session state.
            if len(self._recon_sessions) >= _MAX_RECON_SESSIONS:
                self._recon_sessions.pop(next(iter(self._recon_sessions)))
            session = ReconcileSession(self._held_cids())
            self._recon_sessions[session_id] = session
        else:
            session = self._recon_sessions.get(session_id)
            if session is None:
                # Unknown/expired session (e.g. we converged + dropped it already):
                # an empty result ends the exchange cleanly on the initiator side.
                return {"kind": RECON_RESULT, "frames": []}
        reply = session.respond(batch)
        if not reply or session.done:
            # Converged on our side: free the session state immediately.
            self._recon_sessions.pop(session_id, None)
        return {"kind": RECON_RESULT, "frames": reply}
